package enumerators;

public enum Department {
    ENGLISH, MATH, SCIENCE, HISTORY, PHYSICAL_EDUCATION, ART, MUSIC
}
