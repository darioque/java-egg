package enumerators;

public enum MaritalStatus {
    SINGLE, MARRIED, DIVORCED, WIDOWED
}
