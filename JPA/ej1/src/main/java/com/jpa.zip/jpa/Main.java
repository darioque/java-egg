package com.jpa;

import com.jpa.services.Menu;

public class Main {
    public static void main(String[] args) throws Exception {

        Menu menu = new Menu();
        menu.start();

    }
}